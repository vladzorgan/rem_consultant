import sys
import os

from app.handlers import show_menu, message_handler, settings, region_selection, cities_selection, search_service_centers, region_button_handler, city_button_handler

# Добавляем корневую директорию проекта в sys.path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

import logging
from telegram import Update
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters

from app.config import TELEGRAM_BOT_TOKEN

# Enable logging
logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)
# set higher logging level for httpx to avoid all GET and POST requests being logged
logging.getLogger("httpx").setLevel(logging.WARNING)

logger = logging.getLogger(__name__)

def main() -> None:
    """Start the bot."""
    # Create the Application and pass it your bot's token.
    application = Application.builder().token(TELEGRAM_BOT_TOKEN).build()

    # Обработчики команд
    application.add_handler(CommandHandler("start", show_menu))
    application.add_handler(CommandHandler("settings", settings))
    application.add_handler(CommandHandler("regions", region_selection))
    application.add_handler(CommandHandler("cities", cities_selection))
    application.add_handler(CommandHandler("search_centers", search_service_centers))

    # Обработчики кнопок
    application.add_handler(CallbackQueryHandler(region_button_handler, pattern="^region_"))
    application.add_handler(CallbackQueryHandler(city_button_handler, pattern="^city_"))

    # Обработчики сообщений
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, message_handler))

    application.run_polling()
    # Run the bot until the user presses Ctrl-C
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()