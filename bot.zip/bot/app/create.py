import httpx

from app.config import API_URL

async def create_user(data):
    """Сохраняет выбранный город для пользователя"""
    try:
        # Отправляем POST-запрос на ваше API
        async with httpx.AsyncClient() as client:
            await client.post(f"{API_URL}/api/user", json=data)
    except httpx.RequestError as e:
        print(f"Ошибка при подключении к API: {e}")