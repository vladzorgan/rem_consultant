from telegram import Update
from telegram.ext import CallbackContext
from .keyboards import regions_keyboard, cities_keyboard, service_center_keyboard, main_menu_keyboard, \
    user_settings_keyboard
from .services import fetch_regions, fetch_cities, fetch_service_centers, update_user_city

async def region_button_handler(update: Update, context: CallbackContext):
    """Обработчик для выбора региона"""
    query = update.callback_query
    callback_data = query.data
    if callback_data.startswith("region_"):
        region_id = int(callback_data.split("_")[1])
        await query.edit_message_text("Выберите город:", reply_markup=cities_keyboard(await fetch_cities(region_id)))

async def city_button_handler(update: Update, context: CallbackContext):
    """Обработчик для выбора города"""
    query = update.callback_query
    telegram_id = query.from_user.id
    callback_data = query.data
    city_id = callback_data.split("_")[1]

    if city_id != 'back':
        city_id = int(city_id)
        await query.answer(f"Вы выбрали город с ID {city_id}")
        await update_user_city(telegram_id, city_id)
        await query.edit_message_text(f"Вы выбрали город с ID {city_id}")
    else:
        regions = await fetch_regions()  # Функция для получения всех регионов из БД
        keyboard = regions_keyboard(regions)
        await query.edit_message_text("Выберите регион", reply_markup=keyboard)

async def show_menu(update, context):
    """Обработчик для отображения основного меню"""
    keyboard = main_menu_keyboard()
    await update.message.reply_text("Главное меню", reply_markup=keyboard)

async def settings(update, context):
    """Обработчик для отображения настроек пользователя"""
    keyboard = user_settings_keyboard()
    await update.message.reply_text("Настройки пользователя", reply_markup=keyboard)

async def region_selection(update, context):
    """Обработчик для выбора региона"""
    regions = await fetch_regions()
    keyboard = regions_keyboard(regions)
    await update.message.reply_text("Выберите регион", reply_markup=keyboard)

async def cities_selection(update, context):
    """Обработчик для выбора города"""
    cities = await fetch_cities()  # Функция для получения всех городов из БД
    keyboard = cities_keyboard(cities)
    await update.message.reply_text("Выберите город", reply_markup=keyboard)

async def search_service_centers(update, context):
    """Обработчик для поиска сервисных центров"""
    service_centers = await fetch_service_centers()  # Функция для получения сервисных центров
    keyboard = service_center_keyboard(service_centers)
    await update.message.reply_text("Выберите сервисный центр", reply_markup=keyboard)

async def message_handler(update: Update, context: CallbackContext):
    """Обработчик сообщений пользователей"""
    text = update.message.text
    if text == "Сервисные центры 🛠️":
        await update.message.reply_text("Ищем сервисные центры...")
        # Добавить логику поиска сервисных центров
    elif text == "Узнать цену ремонта 💰":
        await update.message.reply_text("Выберите модель для расчета стоимости...")
        # Добавить логику выбора модели и бренда
    elif text == "Настройки пользователя ⚙️":
        await settings(update, context)  # Показываем меню настроек
    elif text == "Выбрать город по умолчанию 🌍":
        await region_selection(update, context)
        # Логика для выбора города
    elif text == "Посмотреть мои настройки 📋":
        await update.message.reply_text("Вот ваши настройки...")
        # Логика для просмотра настроек пользователя
    elif text == "Назад 🔙":
        await show_menu(update, context)  # Возвращаемся в главное меню