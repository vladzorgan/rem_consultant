import httpx

from app.config import API_URL

async def update_user_city(telegram_id: int, city_id: int):
    """Сохраняет выбранный город для пользователя"""
    try:
        # Отправляем POST-запрос на ваше API
        async with httpx.AsyncClient() as client:
            await client.put(f"{API_URL}/api/user/city", json={"telegram_id": telegram_id, "city_id": city_id})
    except httpx.RequestError as e:
        print(f"Ошибка при подключении к API: {e}")