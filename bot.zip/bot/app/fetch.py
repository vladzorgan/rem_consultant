import httpx

from app.config import API_URL

async def fetch_regions():
    """Загружает список брендов из API."""
    async with httpx.AsyncClient() as client:
        response = await client.get(f"{API_URL}/api/regions")
        if response.status_code == 200:
            return response.json()
        return []

async def fetch_user(telegram_id: int):
    """Загружает список брендов из API."""
    async with httpx.AsyncClient() as client:
        response = await client.get(f"{API_URL}/api/users/{telegram_id}")
        if response.status_code == 200:
            return response.json()
        return None

async def fetch_cities(region_id: int):
    """Загружает список брендов из API."""
    async with httpx.AsyncClient() as client:
        response = await client.get(f"{API_URL}/api/cities?region_id={region_id}")
        if response.status_code == 200:
            return response.json()
        return []

async def fetch_brands():
    """Загружает список брендов из API."""
    async with httpx.AsyncClient() as client:
        response = await client.get(f"{API_URL}/api/device_brands")
        if response.status_code == 200:
            return response.json()
        return []