from telegram import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardButton, InlineKeyboardMarkup

# Клавиатуры для разных частей бота

def main_menu_keyboard():
    """Основное меню с кнопками и иконками"""
    keyboard = [
        [KeyboardButton("Сервисные центры 🛠️")],
        [KeyboardButton("Узнать цену ремонта 💰")],
        [KeyboardButton("Настройки пользователя ⚙️")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=False)

def user_settings_keyboard():
    """Меню настроек пользователя"""
    keyboard = [
        [KeyboardButton("Выбрать город по умолчанию 🌍")],
        [KeyboardButton("Посмотреть мои настройки 📋")],
        [KeyboardButton("Назад 🔙")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=False)

def regions_keyboard(regions):
    """Клавиатура для выбора региона (inline, 2 колонки)"""
    keyboard = []
    for i in range(0, len(regions), 2):
        row = [InlineKeyboardButton(regions[i]['name'], callback_data=f"region_{regions[i]['id']}")]
        if i + 1 < len(regions):
            row.append(InlineKeyboardButton(regions[i + 1]['name'], callback_data=f"region_{regions[i + 1]['id']}"))
        keyboard.append(row)
    return InlineKeyboardMarkup(keyboard)

def cities_keyboard(cities):
    """Клавиатура для выбора города (inline)"""
    keyboard = []
    for i in range(0, len(cities), 2):
        row = [InlineKeyboardButton(cities[i]['name'], callback_data=f"city_{cities[i]['id']}")]
        if i + 1 < len(cities):
            row.append(InlineKeyboardButton(cities[i + 1]['name'], callback_data=f"city_{cities[i + 1]['id']}"))
        keyboard.append(row)
    keyboard.append([InlineKeyboardButton("Назад", callback_data="city_back")])
    return InlineKeyboardMarkup(keyboard)

def service_center_keyboard(service_centers):
    """Клавиатура для выбора сервисных центров"""
    keyboard = [[KeyboardButton(center.name)] for center in service_centers]
    keyboard.append([KeyboardButton("Назад")])
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=True)