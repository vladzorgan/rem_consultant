import httpx

# Функции для работы с базой данных и внешними сервисами

from .config import API_URL

async def fetch_regions():
    """Загружает список брендов из API."""
    async with httpx.AsyncClient() as client:
        response = await client.get(f"{API_URL}/api/regions")
        if response.status_code == 200:
            return response.json()
        return []

async def fetch_user(telegram_id: int):
    """Загружает список брендов из API."""
    async with httpx.AsyncClient() as client:
        response = await client.get(f"{API_URL}/api/users/{telegram_id}")
        if response.status_code == 200:
            return response.json()
        return None

async def fetch_cities(region_id: int):
    """Загружает список брендов из API."""
    async with httpx.AsyncClient() as client:
        response = await client.get(f"{API_URL}/api/cities?region_id={region_id}")
        if response.status_code == 200:
            return response.json()
        return []

async def fetch_brands():
    """Загружает список брендов из API."""
    async with httpx.AsyncClient() as client:
        response = await client.get(f"{API_URL}/api/device_brands")
        if response.status_code == 200:
            return response.json()
        return []

async def fetch_service_centers():
    """Загружает список брендов из API."""
    async with httpx.AsyncClient() as client:
        response = await client.get(f"{API_URL}/api/service_centers")
        if response.status_code == 200:
            return response.json()
        return []

async def update_user_city(telegram_id: int, city_id: int):
    """Сохраняет выбранный город для пользователя"""
    try:
        # Отправляем POST-запрос на ваше API
        async with httpx.AsyncClient() as client:
            await client.put(f"{API_URL}/api/user/city", json={"telegram_id": telegram_id, "city_id": city_id})
    except httpx.RequestError as e:
        print(f"Ошибка при подключении к API: {e}")


async def create_user(data):
    """Сохраняет выбранный город для пользователя"""
    try:
        # Отправляем POST-запрос на ваше API
        async with httpx.AsyncClient() as client:
            await client.post(f"{API_URL}/api/user", json=data)
    except httpx.RequestError as e:
        print(f"Ошибка при подключении к API: {e}")