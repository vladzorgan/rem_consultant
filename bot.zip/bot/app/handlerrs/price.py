from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes
import httpx
# from app.helpers.sendLog import sendLog
from functools import lru_cache

# Импорт конфигурационных переменных
from app.config import API_URL
CACHE_EXPIRATION = 3600  # Кэширование на 1 час

# Кэшируем данные с помощью lru_cache
async def fetch_brands():
    """Загружает список брендов из API."""
    async with httpx.AsyncClient() as client:
        response = await client.get(f"{API_URL}/api/device_brands")
        if response.status_code == 200:
            return response.json()
        return []

async def fetch_models(brand_id: int):
    """Загружает список моделей для бренда из API."""
    async with httpx.AsyncClient() as client:
        response = await client.get(f"{API_URL}/api/device_models?brand_id={brand_id}")
        if response.status_code == 200:
            return response.json()
        return []

async def fetch_repairs():
    """Загружает список ремонтов для модели из API."""
    async with httpx.AsyncClient() as client:
        response = await client.get(f"{API_URL}/api/repairs")
        if response.status_code == 200:
            return response.json()
        return []

async def fetch_services_centers(repair_id: str):
    """Загружает список сервисных центров для модели из API."""
    async with httpx.AsyncClient() as client:
        response = await client.get(f"{API_URL}/api/services_centers?repair_id={repair_id}")
        if response.status_code == 200:
            return response.json()
        return []

async def handle_city(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Определяем, откуда берем данные: из команды или callback-запроса
    if update.message and context.args:
        # Режим команды
        city = " ".join(context.args).strip()
        user_id = update.message.from_user.id
        request_text = update.message.text
        chat_id = update.message.chat_id
    else:
        # Режим callback-запроса
        query = update.callback_query
        await query.answer()
        city = context.user_data.get("city")
        user_id = query.from_user.id
        request_text = query.message.text
        chat_id = query.message.chat_id

    # Проверяем, что город указан
    if not city:
        await context.bot.send_message(chat_id, "Город не указан. Введите /price [город].")
        return

    # Сохраняем город в контексте
    context.user_data["city"] = city

    # Отправляем POST-запрос на API для сохранения лога
    # await sendLog({
    #     "telegram_user_id": user_id,
    #     "request_text": request_text,
    #     "response_text": {'Тест'}
    # })

    # Загружаем бренды
    brands = await fetch_brands()
    if not brands:
        await context.bot.send_message(chat_id, "Бренды не найдены. Попробуйте позже.")
        return

    # Создаем клавиатуру с брендами
    keyboard = [
        [InlineKeyboardButton(brand['name'], callback_data=f"brand_{brand['id']}")]
        for brand in brands
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    # Отправляем сообщение с клавиатурой
    await context.bot.send_message(chat_id, "Выберите бренд:", reply_markup=reply_markup)


# Обработчик выбора бренда
async def handle_brand(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Определяем, откуда берем данные: из команды или callback-запроса
    if update.message and context.args:
        # Режим команды (если нужно)
        brand_id = int(context.args[0])  # Пример, если brand_id передается как аргумент
        user_id = update.message.from_user.id
        chat_id = update.message.chat_id
    else:
        # Режим callback-запроса
        query = update.callback_query
        await query.answer()
        brand_id = int(query.data.split("_")[1])
        user_id = query.from_user.id
        chat_id = query.message.chat_id

    # Сохраняем brand_id в контексте
    context.user_data["brand_id"] = brand_id

    # Загружаем модели для выбранного бренда
    models = await fetch_models(brand_id)
    if not models:
        await context.bot.send_message(chat_id, "Модели не найдены. Попробуйте позже.")
        return

    # Создаем клавиатуру с моделями
    keyboard = [
        [InlineKeyboardButton(model['name'], callback_data=f"model_{model['id']}")]
        for model in models
    ]
    # Добавляем кнопку "Назад"
    keyboard.append([InlineKeyboardButton("⬅️ Назад", callback_data="back_to_brands")])
    reply_markup = InlineKeyboardMarkup(keyboard)

    # Отправляем или обновляем сообщение с клавиатурой
    if update.message:
        await context.bot.send_message(chat_id, "Выберите модель:", reply_markup=reply_markup)
    else:
        await query.edit_message_text("Выберите модель:", reply_markup=reply_markup)

async def handle_model(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Определяем, откуда берем данные: из команды или callback-запроса
    if update.message and context.args:
        # Режим команды (если нужно)
        model_id = int(context.args[0])  # Пример, если model_id передается как аргумент
        user_id = update.message.from_user.id
        chat_id = update.message.chat_id
    else:
        # Режим callback-запроса
        query = update.callback_query
        await query.answer()
        model_id = int(query.data.split("_")[1])
        user_id = query.from_user.id
        chat_id = query.message.chat_id

    # Сохраняем model_id в контексте
    context.user_data["model_id"] = model_id

    # Загружаем ремонты для выбранной модели
    repairs = await fetch_repairs(model_id)
    if not repairs:
        await context.bot.send_message(chat_id, "Ремонты не найдены. Попробуйте позже.")
        return

    # Создаем клавиатуру с ремонтами
    keyboard = [
        [InlineKeyboardButton(repair, callback_data=f"repair_{repair}")]
        for repair in repairs
    ]
    # Добавляем кнопку "Назад"
    keyboard.append([InlineKeyboardButton("⬅️ Назад", callback_data="back_to_models")])
    reply_markup = InlineKeyboardMarkup(keyboard)

    # Отправляем или обновляем сообщение с клавиатурой
    if update.message:
        await context.bot.send_message(chat_id, "Выберите ремонт:", reply_markup=reply_markup)
    else:
        await query.edit_message_text("Выберите ремонт:", reply_markup=reply_markup)

# Обработчик выбора ремонта
async def handle_repair(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Определяем, откуда берем данные: из команды или callback-запроса
    if update.message and context.args:
        # Режим команды (если нужно)
        repair_id = int(context.args[0])  # Пример, если repair_id передается как аргумент
        user_id = update.message.from_user.id
        chat_id = update.message.chat_id
    else:
        # Режим callback-запроса
        query = update.callback_query
        await query.answer()
        repair_id = int(query.data.split("_")[1])
        user_id = query.from_user.id
        chat_id = query.message.chat_id

    # Сохраняем repair_id в контексте
    context.user_data["repair_id"] = repair_id

    # Получаем сохраненные данные
    city = context.user_data.get("city")
    brand_id = context.user_data.get("brand_id")
    model_id = context.user_data.get("model_id")

    # Проверяем, что все данные доступны
    if not all([city, brand_id, model_id, repair_id]):
        await context.bot.send_message(chat_id, "Недостаточно данных для выполнения запроса.")
        return

    # Формируем URL для запроса
    url = f"{API_URL}/prices/{city}/{brand_id}/{model_id}/{repair_id}"
    try:
        response = httpx.get(url)
        response.raise_for_status()  # Проверяем статус ответа
    except httpx.HTTPStatusError as e:
        await context.bot.send_message(chat_id, f"Ошибка при запросе к API: {e}")
        return
    except Exception as e:
        await context.bot.send_message(chat_id, f"Неизвестная ошибка: {e}")
        return

    # Обработка ответа
    prices = response.json()
    if prices:
        result = "\n".join([f"{price['center_name']}: {price['price']} руб." for price in prices])
        await context.bot.send_message(chat_id, f"Цены на ремонт в {city}:\n{result}")
    else:
        await context.bot.send_message(chat_id, "Цены не найдены.")


# Обработчик кнопки "Назад"
async def handle_back(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.data == "back_to_brands":
        await handle_city(update, context)  # Переходим к выбору города
    elif query.data == "back_to_models":
        await handle_brand(update, context)  # Переходим к выбору бренда