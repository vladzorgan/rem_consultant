from telegram import Update, KeyboardButton, ReplyKeyboardMarkup
from telegram.ext import ContextTypes, CallbackContext

from .start import start
from app.keyboards import region_selection, settings, go_back


async def handle_message(update: Update, context: CallbackContext):
    """Обработчик сообщений пользователей"""
    text = update.message.text
    if text == "Сервисные центры 🛠️":
        await update.message.reply_text("Ищем сервисные центры...")
        # Добавить логику поиска сервисных центров
    elif text == "Узнать цену ремонта 💰":
        await update.message.reply_text("Выберите модель для расчета стоимости...")
        # Добавить логику выбора модели и бренда
    elif text == "Настройки пользователя ⚙️":
        await settings(update, context)  # Показываем меню настроек
    elif text == "Выбрать город по умолчанию 🌍":
        await region_selection(update, context)
        # Логика для выбора города
    elif text == "Посмотреть мои настройки 📋":
        await update.message.reply_text("Вот ваши настройки...")
        # Логика для просмотра настроек пользователя
    elif text == "Назад 🔙":
        await go_back(update, context)  # Возвращаемся в главное меню