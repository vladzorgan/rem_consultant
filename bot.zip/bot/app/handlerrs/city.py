from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import CallbackContext

from app.fetch import fetch_cities, fetch_regions
from app.update import update_user_city

def regions_keyboard(regions):
    """Клавиатура для выбора региона (inline, 2 колонки)"""
    # Разбиваем регионы на две колонки
    keyboard = []
    for i in range(0, len(regions), 2):
        row = [
            InlineKeyboardButton(regions[i]['name'], callback_data=f"region_{regions[i]['id']}")
        ]
        if i + 1 < len(regions):
            row.append(InlineKeyboardButton(regions[i + 1]['name'], callback_data=f"region_{regions[i + 1]['id']}"))
        keyboard.append(row)

    return InlineKeyboardMarkup(keyboard)

def cities_keyboard(cities):
    """Клавиатура для выбора города (inline)"""
    keyboard = []
    for i in range(0, len(cities), 2):
        row = [
            InlineKeyboardButton(cities[i]['name'], callback_data=f"city_{cities[i]['id']}")
        ]
        if i + 1 < len(cities):
            row.append(InlineKeyboardButton(cities[i + 1]['name'], callback_data=f"city_{cities[i + 1]['id']}"))
        keyboard.append(row)
    keyboard.append([InlineKeyboardButton("Назад", callback_data="city_back")])  # Кнопка "Назад"
    return InlineKeyboardMarkup(keyboard)

# Обработчик для выбора региона
async def region_button_handler(update: Update, context: CallbackContext):
    query = update.callback_query
    callback_data = query.data

    if callback_data.startswith("region_"):
        region_id = int(callback_data.split("_")[1])

        await query.edit_message_text("Выберите город:", reply_markup=cities_keyboard(await fetch_cities(region_id)))

# Обработчик для выбора города
async def city_button_handler(update: Update, context: CallbackContext):
    query = update.callback_query
    telegram_id = query.from_user.id
    callback_data = query.data
    city_id = callback_data.split("_")[1]

    if city_id != 'back':
        city_id = int(city_id)
        await query.answer(f"Вы выбрали город с ID {city_id}")

        # Сохраняем город
        await update_user_city(telegram_id, city_id)

        # Редактируем сообщение
        await query.edit_message_text(f"Вы выбрали город с ID {city_id}")
    else:
        regions = await fetch_regions()  # Функция для получения всех городов из БД
        keyboard = regions_keyboard(regions)
        await query.edit_message_text("Выберите регион", reply_markup=keyboard)

async def region_selection(update, context):
    await update.message.reply_text("Выберите регион", reply_markup=regions_keyboard(await fetch_regions()))

async def cities_selection(update, context):
    await update.message.reply_text("Выберите город", reply_markup=cities_keyboard(await fetch_cities()))