from telegram import Update
from telegram.ext import ContextTypes

async def service_centers(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Я помогу тебе найти цены на устройства в сервисных центрах. Просто напиши команду в формате:\n"
        "/price [город] [бренд устройства] [модель устройства] [что надо починить].\nПример: /price Москва iphone 12 замена дисплея")